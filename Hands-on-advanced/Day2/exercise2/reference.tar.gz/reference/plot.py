import os
os.environ["MPLCONFIGDIR"] = "/tmp/mplconfig"
os.makedirs("/tmp/mplconfig", exist_ok=True)

import matplotlib.pyplot as plt

# Data for x_gamma_extrapolation = true
q_mesh_true = [1, 2, 4, 8]
E_true = [-15.82394038, -15.76382033, -15.75148037, -15.75135992]

# Data for x_gamma_extrapolation = false
q_mesh_false = [1, 2, 4, 8]
E_false = [-15.90810436, -15.78168550, -15.75513999, -15.75182448]

# Create the plot
plt.figure(figsize=(8, 6))
plt.plot(q_mesh_true, E_true, marker='o', label='x_gamma_extrapolation = true')
plt.plot(q_mesh_false, E_false, marker='s', label='x_gamma_extrapolation = false')

# Labels and title
plt.xlabel('q-mesh')
plt.ylabel('E (Ry)')
plt.title('Convergence of Total Energy vs. q-mesh')
plt.grid(True)
plt.legend()
plt.tight_layout()

# Save as PDF
plt.savefig('plot.pdf')
plt.show()

